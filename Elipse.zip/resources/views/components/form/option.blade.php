<option value="{{ $value }}" {{ !$selected ?: 'selected="selected"' }} {{ $attributes }}>
    {{ $description }}
</option>
