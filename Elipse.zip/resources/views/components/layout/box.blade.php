<div {{ $attributes->merge(['class' => 'mb-12 xl:mb-0 px-4']) }} >
    <div class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">

        {{ $slot }}

    </div>
</div>
