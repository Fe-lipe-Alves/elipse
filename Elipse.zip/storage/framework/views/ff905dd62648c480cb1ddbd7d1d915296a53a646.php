<?php if (isset($component)) { $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\App::class, []); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\CardPage::class, ['title' => 'Cadastrar novo trabalho']); ?>
<?php $component->withName('layout.card-page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <?php
            $work = $work ?? null;
            $route = $work ?  route('works.update', ['work' => $work->id]) : route('works.store');
        ?>

        <?php if (isset($component)) { $__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Form::class, ['action' => ''.e($route).'','model' => $work]); ?>
<?php $component->withName('form.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'form-work','enctype' => 'multipart/form-data']); ?>
            <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">Informações do trabalho</h6>

            <div class="flex flex-wrap">
                <?php if(auth()->user()->type_of_user_id != \App\Support\Consts\TypeOfUsers::TEACHER): ?>

                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'students_class_id','label' => 'Turma','width' => 'w-full lg:w-4/12']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
                    <?php if(is_null($work)): ?>
                        <?php if (isset($component)) { $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Option::class, ['value' => '','description' => 'Selecione','selected' => true]); ?>
<?php $component->withName('form.option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['disabled' => true,'hidde' => true]); ?>
<?php if (isset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785)): ?>
<?php $component = $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785; ?>
<?php unset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php else: ?>
                        <?php ($studentsClassID = $work->studentsClass()->first()->id); ?>
                    <?php endif; ?>

                    <?php $__currentLoopData = $studentsClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentsClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Option::class, ['value' => $studentsClass->id,'description' => $studentsClass->description,'selected' => ($studentsClassID??false) == $studentsClass->id]); ?>
<?php $component->withName('form.option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data-teachers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('students_class.teachers', ['studentsClass' => $studentsClass->id]))]); ?>
<?php if (isset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785)): ?>
<?php $component = $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785; ?>
<?php unset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 <?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'lesson_id','label' => 'Aula','width' => 'w-full lg:w-4/12 disabled:opacity-50']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
                    <?php if(empty($lessons)): ?>
                        <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Option::class, ['value' => $lesson->id,'description' => $lesson->subject->description,'selected' => $work->lesson_id == $lesson->id]); ?>
<?php $component->withName('form.option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785)): ?>
<?php $component = $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785; ?>
<?php unset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                 <?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'lesson_id','label' => 'Aula','width' => 'w-full lg:w-4/12 disabled:opacity-50']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
                        <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Option::class, ['value' => $lesson->id,'description' => $lesson->studentsClass->description]); ?>
<?php $component->withName('form.option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785)): ?>
<?php $component = $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785; ?>
<?php unset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['type' => 'datetime-local','value' => !is_null($work)?$work->deadline->format('Y-m-d\TH:i'):null,'name' => 'deadline','id' => 'deadline','label' => 'Prazo','width' => 'w-full lg:w-4/12']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'title','id' => 'title','label' => 'Título','width' => 'w-full']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['maxlength' => '150','required' => true]); ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            </div>

            <hr class="mt-6 border-b-1 border-blueGray-300">
            <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">Conteúdo</h6>

            <?php if (isset($component)) { $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Textarea::class, ['name' => 'description','id' => 'description','label' => 'Descrição']); ?>
<?php $component->withName('form.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['rows' => '10','required' => true]); ?><?php echo e(is_null($work)?'':$work->description); ?> <?php if (isset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3)): ?>
<?php $component = $__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3; ?>
<?php unset($__componentOriginalf8cd5da1f0638b515671893a5c50321461c3eee3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            <div class="w-full px-4">
                <div class="relative w-full mb-3">
                        <label class="block uppercase text-blueGray-600 text-xs font-bold mb-2" for="">
                            Arquivos
                        </label>

                    <input type="file" class="hidden" name="files" id="files" multiple="multiple" />
                    <div id="box-input-file" class="border-0 border-transparent flex flex-col items-center justify-center px-3 py-5 h-32 text-blueGray-500 cursor-pointer bg-blueGray-50 rounded text-sm shadow w-full ease-linear transition-all duration-150">
                        Clique ou solte os arquivos aqui
                    </div>

                    <div id="table-files" class=" <?php if(is_null($work)): ?> hidden <?php endif; ?> border-0 px-3 py-5 mt-2 text-blueGray-500 bg-blueGray-50 rounded text-sm shadow w-full">
                        <table class="items-center w-full bg-transparent border-collapse">
                            <thead>
                                <tr>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Arquivo
                                    </th>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Tipo
                                    </th>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Tamanho
                                    </th>
                                    <th class="w-12 px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Remover
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(!is_null($work)): ?>
                                    <?php $__currentLoopData = $work->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="item-file">
                                            <th class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-left">
                                                <a target="_blank" href="<?php echo e(\Illuminate\Support\Facades\Storage::url($file->source)); ?>"><?php echo e($file->name); ?></a>
                                            </th>
                                            <td class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                <?php echo e($file->type); ?>

                                            </td>
                                            <td class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                <?php echo e($file->size); ?>

                                            </td>
                                            <td class="w-12 border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-center">

                                                <button data-id="<?php echo e($file->id); ?>" type="button" class="remove-file-uploaded bg-gray-200 text-black font-bold px-2 py-1 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"><i class="fas fa-minus"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($work->files->count() == 0): ?>
                                        <tr class="item-file">
                                            <td colspan="4" class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-center">
                                                Não há arquivos
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-red-600">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>


            <hr class="mt-6 border-b-1 border-blueGray-300">

            <div class="flex flex-wrap">
                <div class="w-full lg:w-12/12 px-4">
                    <div class="relative w-full text-center py-6 mb-3">
                        <button
                            class="bg-primary-500 text-white active:bg-emerald-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
                            type="submit"
                        >
                            Salvar
                        </button>
                    </div>
                </div>
            </div>

         <?php if (isset($__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d)): ?>
<?php $component = $__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d; ?>
<?php unset($__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

     <?php if (isset($__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b)): ?>
<?php $component = $__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b; ?>
<?php unset($__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

 <?php $__env->slot('scripts', null, []); ?> 
    <script>
        const routes = {
            teachers: '<?php echo e(route('students_class.teachers', ['studentsClass' => 0])); ?>'
        };
    </script>
    <script src="<?php echo e(asset('js/work.js')); ?>"></script>
 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8)): ?>
<?php $component = $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8; ?>
<?php unset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/works/form.blade.php ENDPATH**/ ?>