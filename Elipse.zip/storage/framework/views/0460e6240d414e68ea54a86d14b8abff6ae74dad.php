<li class="inline-flex">
    <a
        class="text-blueGray-700 hover:text-blueGray-500 text-sm block mb-4 no-underline font-semibold"
        href="<?php echo e($href); ?>"
    >
        <i class="fas <?php echo e($icon); ?> mr-2 text-blueGray-400 text-base"></i>
        <?php echo e($name); ?>

    </a>
</li>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/layouts/components/sidebar-item.blade.php ENDPATH**/ ?>