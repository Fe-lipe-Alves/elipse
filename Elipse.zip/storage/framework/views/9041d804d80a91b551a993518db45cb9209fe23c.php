<nav
    class="md:left-0 md:block md:fixed md:top-0 md:bottom-0 md:overflow-y-auto md:flex-row md:flex-nowrap md:overflow-hidden shadow-xl bg-white flex flex-wrap items-center justify-between relative md:w-64 z-10 py-4 px-6"
>
    <div
        class="md:flex-col md:items-stretch md:min-h-full md:flex-nowrap px-0 flex flex-wrap items-center justify-between w-full mx-auto"
    >
        <button
            class="cursor-pointer text-black opacity-50 md:hidden px-3 py-1 text-xl leading-none bg-transparent rounded border border-solid border-transparent"
            type="button"
            onclick="toggleNavbar('example-collapse-sidebar')"
        >
            <i class="fas fa-bars"></i></button
        >
        <a
            class="md:block text-left md:pb-2 text-blueGray-600 mr-0 inline-block whitespace-nowrap text-sm uppercase font-bold p-4 px-0"
            href="<?php echo e(route('home')); ?>"
        >
            Ajuda - <?php echo e(config('app.name')); ?>

        </a>
        <div
            class="md:flex md:flex-col md:items-stretch md:opacity-100 md:relative md:mt-4 md:shadow-none shadow absolute top-0 left-0 right-0 z-40 overflow-y-auto overflow-x-hidden h-auto items-center flex-1 rounded hidden"
            id="example-collapse-sidebar"
        >
            <ul class="md:flex-col md:min-w-full flex flex-col list-none">
                <li class="items-center">
                    <a
                        class="text-primary-500 hover:text-primary-600 text-xs uppercase py-3 font-bold block"
                        href="<?php echo e(route('help')); ?>"
                    >
                        Introdução</a
                    >
                </li>
            </ul>
            <hr class="my-4 md:min-w-full"/>

            <h6
                class="md:min-w-full text-blueGray-500 text-xs uppercase font-bold block pt-1 pb-4 no-underline"
            >
                Cadastros
            </h6>
            <ul class="md:flex-col md:min-w-full flex flex-col list-none md:mb-4">
                <?php if (isset($component)) { $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\SidebarItem::class, ['href' => ''.e(route('help.users')).'','name' => 'Usuários','icon' => '']); ?>
<?php $component->withName('layout.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358)): ?>
<?php $component = $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358; ?>
<?php unset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\SidebarItem::class, ['href' => ''.e(route('help.subjects')).'','name' => 'Disciplinas','icon' => '']); ?>
<?php $component->withName('layout.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358)): ?>
<?php $component = $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358; ?>
<?php unset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\SidebarItem::class, ['href' => ''.e(route('help.lessons')).'','name' => 'Aulas','icon' => '']); ?>
<?php $component->withName('layout.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358)): ?>
<?php $component = $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358; ?>
<?php unset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\SidebarItem::class, ['href' => ''.e(route('help.students_class')).'','name' => 'Turmas','icon' => '']); ?>
<?php $component->withName('layout.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358)): ?>
<?php $component = $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358; ?>
<?php unset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </ul>


            <hr class="my-4 md:min-w-full"/>

            <h6
                class="md:min-w-full text-blueGray-500 text-xs uppercase font-bold block pt-1 pb-4 no-underline"
            >
                Acadêmico
            </h6>
            <ul class="md:flex-col md:min-w-full flex flex-col list-none md:mb-4">
                <?php if (isset($component)) { $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\SidebarItem::class, ['href' => ''.e(route('help.works')).'','name' => 'Trabalhos','icon' => '']); ?>
<?php $component->withName('layout.sidebar-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358)): ?>
<?php $component = $__componentOriginale7db5802f3aafa5b36313402c0502565517ab358; ?>
<?php unset($__componentOriginale7db5802f3aafa5b36313402c0502565517ab358); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/layouts/components/sidebar-help.blade.php ENDPATH**/ ?>