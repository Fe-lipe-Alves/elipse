<option value="<?php echo e($value); ?>" <?php echo e(!$selected ?: 'selected="selected"'); ?> <?php echo e($attributes); ?>>
    <?php echo e($description); ?>

</option>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/components/form/option.blade.php ENDPATH**/ ?>