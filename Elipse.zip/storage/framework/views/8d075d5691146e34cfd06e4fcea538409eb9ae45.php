<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="theme-color" content="#000000"/>
    <title><?php echo e(config('app.name')); ?></title>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

</head>
<body class="text-blueGray-700 bg-blueGray-50 antialiased">
<noscript>You need to enable JavaScript to run this app.</noscript>

<div id="root">

    <?php if (isset($component)) { $__componentOriginal81ff2617c756881ec4dca57ea9c73f3fa253b792 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Sidebar::class, []); ?>
<?php $component->withName('layout.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal81ff2617c756881ec4dca57ea9c73f3fa253b792)): ?>
<?php $component = $__componentOriginal81ff2617c756881ec4dca57ea9c73f3fa253b792; ?>
<?php unset($__componentOriginal81ff2617c756881ec4dca57ea9c73f3fa253b792); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <div class="relative md:ml-64 bg-blueGray-50">
        <?php if (isset($component)) { $__componentOriginal43d9358d9ada7b0bd870ca8459dc46506ac3d248 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Header::class, []); ?>
<?php $component->withName('layout.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal43d9358d9ada7b0bd870ca8459dc46506ac3d248)): ?>
<?php $component = $__componentOriginal43d9358d9ada7b0bd870ca8459dc46506ac3d248; ?>
<?php unset($__componentOriginal43d9358d9ada7b0bd870ca8459dc46506ac3d248); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <div class="spacer-top py-10"></div>

        <div class="p-10">
            <?php echo e($slot); ?>

        </div>


    </div>

    <form action="" method="post" id="formGeneric" class="hidden">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
    </form>
</div>

</body>
<script
    src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"
    charset="utf-8"
></script>
<script src="https://unpkg.com/@popperjs/core@2.9.1/dist/umd/popper.min.js" charset="utf-8"></script>
<script>
    var user = JSON.parse('<?php echo \Illuminate\Support\Facades\Auth::user()->toJson(); ?>')
</script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php if(isset($scripts)): ?>
    <?php echo e($scripts); ?>

<?php endif; ?>
</html>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/layouts/app.blade.php ENDPATH**/ ?>