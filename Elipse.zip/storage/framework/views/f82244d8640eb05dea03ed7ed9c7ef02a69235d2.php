<?php if(empty($href)): ?>
    <button
        type="button"
        <?php echo e($attributes); ?>

        class="text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:bg-gray-100 text-left"
    >
        <?php echo e($label); ?>

    </button>
<?php else: ?>
    <a
        href="<?php echo e($href); ?>"
        <?php echo e($attributes); ?>

        class="text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:bg-gray-100"
    >
        <?php echo e($label); ?>

    </a>
<?php endif; ?>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/components/layout/drop-down-item.blade.php ENDPATH**/ ?>