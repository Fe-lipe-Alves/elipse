<button
    type="button"
    data-hundle="dropdown"
    data-for="order_dropdown_<?php echo e($order); ?>"
>
    <i class="fas fa-ellipsis-v"></i>
</button>

<div
    class="hidden bg-white text-base z-50 float-left py-2 list-none text-left rounded shadow-lg mt-1"
    style="min-width: 12rem;"
    id="order_dropdown_<?php echo e($order); ?>"
    data-interaction="dropdown"
>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/components/layout/dropdown.blade.php ENDPATH**/ ?>