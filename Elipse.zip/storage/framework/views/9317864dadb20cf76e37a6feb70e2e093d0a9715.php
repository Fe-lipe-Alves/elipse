<?php if (isset($component)) { $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\App::class, []); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\CardPage::class, ['title' => 'Detalhes Trabalho']); ?>
<?php $component->withName('layout.card-page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <div>
            <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">Informações do trabalho</h6>

            <div class="flex flex-wrap">
                <div class="w-full lg:w-4/12 px-4">
                    <div class="relative w-full mb-3 text-blueGray-600">
                        <span class="block uppercase text-xs font-bold mb-2">Turma:</span>
                        <p class="border-0 px-3 py-3 rounded text-sm w-full">
                            <?php echo e($work->studentsClass); ?>

                        </p>
                    </div>
                </div>

                <div class="w-full lg:w-4/12 px-4">
                    <div class="relative w-full mb-3 text-blueGray-600">
                        <span class="block uppercase text-xs font-bold mb-2">Aula:</span>
                        <p class="border-0 px-3 py-3 rounded text-sm w-full">
                            <?php echo e($work->lesson->subject->description); ?>

                        </p>
                    </div>
                </div>

                <div class="w-full lg:w-4/12 px-4">
                    <div class="relative w-full mb-3 text-blueGray-600">
                        <span class="block uppercase text-xs font-bold mb-2">Prazo:</span>
                        <p class="border-0 px-3 py-3 rounded text-sm w-full">
                            <?php echo e($work->deadline->format('d/m/Y H:i:s')); ?>

                        </p>
                    </div>
                </div>

                <div class="w-full px-4">
                    <div class="relative w-full mb-3 text-blueGray-600">
                        <span class="block uppercase text-xs font-bold mb-2">Título:</span>
                        <p class="border-0 px-3 py-3 rounded text-sm w-full">
                            <?php echo e($work->title); ?>

                        </p>
                    </div>
                </div>
            </div>

            <hr class="mt-6 border-b-1 border-blueGray-300">
            <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">Conteúdo</h6>

            <div class="flex flex-wrap">
                <div class="w-full px-4">
                    <div class="relative w-full mb-3 text-blueGray-600">
                        <span class="block uppercase text-xs font-bold mb-2">Descrição:</span>
                        <p class="border-0 px-3 py-3 rounded text-sm w-full">
                            <?php echo e($work->description); ?>

                        </p>
                    </div>
                </div>
            </div>

            <?php if($work->files->count() > 0): ?>
            <div class="w-full px-4">
                <div class="relative w-full mb-3">
                    <label class="block uppercase text-blueGray-600 text-xs font-bold mb-2" for="">
                        Arquivos do Trabalho
                    </label>

                    <div class="border-0 px-3 py-5 mt-2 text-blueGray-500 bg-blueGray-50 rounded text-sm shadow w-full">
                        <table class="items-center w-full bg-transparent border-collapse">
                            <thead>
                                <tr>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Arquivo
                                    </th>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Tipo
                                    </th>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Tamanho
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $work->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="item-file">
                                        <th class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-left">
                                            <a target="_blank" href="<?php echo e(\Illuminate\Support\Facades\Storage::url($file->source)); ?>" class="text-blue-600">
                                                <?php echo e($file->name); ?>

                                            </a>
                                        </th>
                                        <td class="w-14 border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            <?php echo e($file->type); ?>

                                        </td>
                                        <td class="w-14 border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            <?php echo e($file->size); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
            <?php endif; ?>

        </div>

        <?php if(\Illuminate\Support\Facades\Auth::user()->type_of_user_id == \App\Support\Consts\TypeOfUsers::STUDENT): ?>
        <hr class="mt-6 border-b-1 border-blueGray-300">
        <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">Resposta</h6>

        <?php if (isset($component)) { $__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Form::class, ['action' => ''.e(route('works.response', ['work' => $work->id])).'']); ?>
<?php $component->withName('form.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'form-work','enctype' => 'multipart/form-data']); ?>
            <?php if(\Illuminate\Support\Facades\Auth::user()->type_of_user_id == \App\Support\Consts\TypeOfUsers::STUDENT): ?>

                <div class="w-full px-4">
                    <div class="relative w-full mb-3">
                        <label class="block uppercase text-blueGray-600 text-xs font-bold mb-2" for="">
                            Arquivos da Resposta
                        </label>

                        <input type="file" class="hidden" name="files" id="files" multiple="multiple" />
                        <div id="box-input-file" class="border-0 border-transparent flex flex-col items-center justify-center px-3 py-5 h-32 text-blueGray-500 cursor-pointer bg-blueGray-50 rounded text-sm shadow w-full ease-linear transition-all duration-150">
                            Clique ou solte os arquivos aqui
                        </div>

                        <?php
                            $response = $work->response(\Illuminate\Support\Facades\Auth::id())->first();
                        ?>
                        <div id="table-files" class=" <?php if(is_null($response)): ?> hidden <?php endif; ?> border-0 px-3 py-5 mt-2 text-blueGray-500 bg-blueGray-50 rounded text-sm shadow w-full">
                            <table class="items-center w-full bg-transparent border-collapse">
                                <thead>
                                <tr>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Arquivo
                                    </th>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Tipo
                                    </th>
                                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Tamanho
                                    </th>
                                    <th class="w-12 px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                                        Remover
                                    </th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php if(!is_null($response)): ?>
                                    <?php $__currentLoopData = $response->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="item-file">
                                            <th class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-left">
                                                <a target="_blank" href="<?php echo e(\Illuminate\Support\Facades\Storage::url($file->source)); ?>"><?php echo e($file->name); ?></a>
                                            </th>
                                            <td class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                <?php echo e($file->type); ?>

                                            </td>
                                            <td class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                <?php echo e($file->size); ?>

                                            </td>
                                            <td class="w-12 border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-center">

                                                <button data-id="<?php echo e($file->id); ?>" type="button" class="remove-file-uploaded bg-gray-200 text-black font-bold px-2 py-1 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"><i class="fas fa-minus"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($response->files->count() == 0): ?>
                                        <tr class="item-file">
                                            <td colspan="4" class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4 text-center">
                                                Não há arquivos
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-red-600">
                            <?php echo e($message); ?>

                        </small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="flex flex-wrap">
                    <div class="w-full lg:w-12/12 px-4">
                        <div class="relative w-full text-center py-6 mb-3">
                            <button
                                class="bg-primary-500 text-white active:bg-emerald-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
                                type="submit"
                            >
                                Salvar
                            </button>
                        </div>
                    </div>
                </div>

            <?php endif; ?>
         <?php if (isset($__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d)): ?>
<?php $component = $__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d; ?>
<?php unset($__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php if (isset($__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b)): ?>
<?php $component = $__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b; ?>
<?php unset($__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

     <?php $__env->slot('scripts', null, []); ?> 
        <script src="<?php echo e(asset('js/work.js')); ?>"></script>
     <?php $__env->endSlot(); ?>

 <?php if (isset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8)): ?>
<?php $component = $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8; ?>
<?php unset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/works/show.blade.php ENDPATH**/ ?>