<div class="<?php echo e($width); ?> px-4">

    <div class="relative w-full mb-3">

        <?php if($label): ?>
            <label
                class="block uppercase text-blueGray-600 text-xs font-bold mb-2
                    <?php echo e($attributes->has('required') ? 'required' : ''); ?>"
                for="<?php echo e($id); ?>"
            >
                <?php echo e($label); ?>

            </label>
        <?php endif; ?>


        <input type="<?php echo e($type); ?>"
               class="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
               name="<?php echo e($name); ?>"
               id="<?php echo e($id); ?>"
               value="<?php echo e($value); ?>"
               <?php echo e($attributes); ?>

        >

        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-red-600">
                <?php echo e($message); ?>

            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/components/form/input.blade.php ENDPATH**/ ?>