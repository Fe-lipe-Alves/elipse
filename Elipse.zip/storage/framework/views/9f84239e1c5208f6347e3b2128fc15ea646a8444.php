<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <meta name="theme-color" content="#000000" />
    <title><?php echo e(config('app.name')); ?></title>
</head>
<body class="text-gray-800 antialiased">

    <?php echo e($slot); ?>


</body>
<script>
    function toggleNavbar(collapseID) {
        document.getElementById(collapseID).classList.toggle("hidden");
        document.getElementById(collapseID).classList.toggle("block");
    }
</script>
</html>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/layouts/guest.blade.php ENDPATH**/ ?>