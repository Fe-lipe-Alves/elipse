<form action="<?php echo e($action); ?>" method="<?php echo e($method); ?>" <?php echo e($attributes); ?>>
    <?php echo csrf_field(); ?>

    <?php if(!is_null($model)): ?>
        <?php echo method_field('put'); ?>
    <?php endif; ?>

    <?php echo e($slot); ?>


</form>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/components/form/form.blade.php ENDPATH**/ ?>