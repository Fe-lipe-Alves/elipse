<?php if (isset($component)) { $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\App::class, []); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginalf3d12ed70acbf72416382bf54290ba1e05575439 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Box::class, []); ?>
<?php $component->withName('layout.box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full']); ?>
        <div class="rounded-t mb-0 px-4 py-3 border-0">
            <div class="flex flex-wrap items-center">
                <div class="relative w-full px-4 max-w-full flex-grow flex-1">
                    <h3 class="font-semibold text-base text-blueGray-700">
                        Trabalhos
                    </h3>
                </div>
                <div class="relative w-full px-4 max-w-full flex-grow flex-1 text-right">
                    <?php if(auth()->user()->type_of_user_id != \App\Support\Consts\TypeOfUsers::STUDENT): ?>
                        <a
                            class="bg-primary-500 text-white active:bg-indigo-600 text-xs font-bold uppercase px-3 py-1 rounded outline-none focus:outline-none mr-1 mb-1"
                            type="button"
                            style="transition:all .15s ease"
                            href="<?php echo e(route('works.create')); ?>"
                        >
                            Novo
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="block w-full overflow-x-auto">
            <!-- Projects table -->
            <table class="items-center w-full bg-transparent border-collapse">
                <thead>
                <tr>
                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                        Turma
                    </th>
                    <th class="flex-1 px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                        Disciplina
                    </th>
                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                        Título
                    </th>
                    <th class="px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">
                        Prazo
                    </th>
                    <th class="w-1 px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left">

                    </th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <?php echo e($work->studentsClass); ?>

                        </td>
                        <td class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <?php echo e($work->subject->description); ?>

                        </td>
                        <td class="w-5/12 max-w-lg overflow-ellipsis overflow-hidden border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <a href="<?php echo e(route('works.show', ['work' => $work->id])); ?>" class="text-blue-600"><?php echo e($work->title); ?></a>
                        </td>
                        <td class="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <?php echo e($work->deadline->format('d/m/Y')); ?>

                        </td>
                        <td class="w-1 border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <?php if (isset($component)) { $__componentOriginalfc1e6dcb062f4a9e8059b4f811d4b99aca9f96fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Dropdown::class, ['ref' => $work->id]); ?>
<?php $component->withName('layout.dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

                                <?php if (isset($component)) { $__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\DropdownItem::class, ['label' => 'Editar','href' => route('works.edit', ['work' => $work->id])]); ?>
<?php $component->withName('layout.dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777)): ?>
<?php $component = $__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777; ?>
<?php unset($__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                                <?php if (isset($component)) { $__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\DropdownItem::class, ['label' => 'Apagar']); ?>
<?php $component->withName('layout.dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['data-action' => 'destroy','data-route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('works.destroy', ['work' => $work->id]))]); ?>
<?php if (isset($__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777)): ?>
<?php $component = $__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777; ?>
<?php unset($__componentOriginalcd35b366ad0b71317e787ec0113f6d5b1dcd2777); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                             <?php if (isset($__componentOriginalfc1e6dcb062f4a9e8059b4f811d4b99aca9f96fd)): ?>
<?php $component = $__componentOriginalfc1e6dcb062f4a9e8059b4f811d4b99aca9f96fd; ?>
<?php unset($__componentOriginalfc1e6dcb062f4a9e8059b4f811d4b99aca9f96fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
     <?php if (isset($__componentOriginalf3d12ed70acbf72416382bf54290ba1e05575439)): ?>
<?php $component = $__componentOriginalf3d12ed70acbf72416382bf54290ba1e05575439; ?>
<?php unset($__componentOriginalf3d12ed70acbf72416382bf54290ba1e05575439); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

 <?php if (isset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8)): ?>
<?php $component = $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8; ?>
<?php unset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/works/index.blade.php ENDPATH**/ ?>