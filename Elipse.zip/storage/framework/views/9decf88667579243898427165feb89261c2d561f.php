<?php if (isset($component)) { $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\App::class, []); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\CardPage::class, ['title' => 'Cadastrar nova aula']); ?>
<?php $component->withName('layout.card-page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

        <?php
            $studentsClass = $studentsClass ?? null;
            $route = $studentsClass ?  route('students_class.update', ['studentsClass' => $studentsClass->id]) : route('students_class.store');
        ?>

        <?php if (isset($component)) { $__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Form::class, ['action' => ''.e($route).'','model' => $studentsClass]); ?>
<?php $component->withName('form.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">Informações da aula</h6>

            <div class="flex flex-wrap">

                <?php if (isset($component)) { $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Input::class, ['name' => 'name','id' => 'name','label' => 'Nome','width' => 'w-full lg:w-4/12']); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['placeholder' => 'Exemplo: A','required' => true]); ?>
<?php if (isset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7)): ?>
<?php $component = $__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7; ?>
<?php unset($__componentOriginal2d3054491160b5bc178f52d0506862417e45bea7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Select::class, ['name' => 'grade_id','options' => $grade,'label' => 'Série','value' => 'value','width' => 'w-full lg:w-4/12']); ?>
<?php $component->withName('form.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
<?php if (isset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448)): ?>
<?php $component = $__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448; ?>
<?php unset($__componentOriginal0c320afe67255a3836591594c37d4ada9ba90448); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

            </div>

            <hr class="mt-6 border-b-1 border-blueGray-300">
            <h6 class="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">Alunos</h6>

            <div class="flex flex-wrap">

                <div class="block w-5.5/12 overflow-x-auto px-4">
                    <label class="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                        Todos os alunos
                    </label>
                    <div id="list-all" class="border-0 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow w-full h-96">

                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button
                                type="button"
                                class="student text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent hover:bg-blue-100 text-blueGray-700 hover:shadow-sm text-left"
                                data-id="<?php echo e($student->id); ?>"
                                data-list="all"
                                data-active="false"
                                <?php if(!is_null($studentsClass)): ?>
                                    style="<?php echo e(!$studentsClass->students->contains('id', $student->id) ?: 'display:none'); ?>"
                                <?php endif; ?>
                            >
                                <?php echo e($student->name); ?>

                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

                <div class="w-1/12 flex flex-col content-center justify-center">
                    <div class="text-center">
                        <button
                            type="button"
                            class="bg-white active:bg-emerald-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none m-1 my-2 ease-linear transition-all duration-150"
                            id="add-class"
                        >
                            <i class="fas fa-arrow-right"></i>
                        </button>
                        <button
                            type="button"
                            class="bg-white active:bg-emerald-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none m-1 my-2 ease-linear transition-all duration-150"
                            id="remove-class"
                        >
                            <i class="fas fa-arrow-left"></i>
                        </button>
                    </div>
                </div>


                <div class="block w-5.5/12 overflow-x-auto px-4">
                    <label class="block uppercase text-blueGray-600 text-xs font-bold mb-2 required">
                        Alunos desta turma
                    </label>
                    <div id="list-class" class="border-0 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow w-full h-96">

                        <?php if(!is_null($studentsClass)): ?>
                            <?php $__currentLoopData = $studentsClass->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button
                                    type="button"
                                    class="student text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:bg-blue-100 hover:shadow-sm text-left"
                                    data-id="<?php echo e($student->id); ?>"
                                >
                                    <input type="hidden" name="students[]" value="<?php echo e($student->id); ?>">
                                    <?php echo e($student->name); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                    <div class="w-full">
                        <small class="text-red-600">
                            <?php $__errorArgs = ['students'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </small>
                    </div>
                </div>
            </div>

            <hr class="mt-6 border-b-1 border-blueGray-300">

            <div class="flex flex-wrap">
                <div class="w-full lg:w-12/12 px-4">
                    <div class="relative w-full text-center py-6 mb-3">
                        <button
                            class="bg-primary-500 text-white active:bg-emerald-600 font-bold uppercase text-xs px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none mr-1 ease-linear transition-all duration-150"
                            type="submit"
                        >
                            Salvar
                        </button>
                    </div>
                </div>
            </div>

         <?php if (isset($__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d)): ?>
<?php $component = $__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d; ?>
<?php unset($__componentOriginale864dcd5d16c970cc29f2ed7e27e93b029fd489d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

     <?php if (isset($__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b)): ?>
<?php $component = $__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b; ?>
<?php unset($__componentOriginal81d4b60562e818ad3e611d763d5571761b93a66b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

 <?php $__env->slot('scripts', null, []); ?> 
    <script src="<?php echo e(asset('js/studentsClass.js')); ?>"></script>
 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8)): ?>
<?php $component = $__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8; ?>
<?php unset($__componentOriginal7bcb47133ab1e04b8b45962d47c0583745930df8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/students-classes/form.blade.php ENDPATH**/ ?>