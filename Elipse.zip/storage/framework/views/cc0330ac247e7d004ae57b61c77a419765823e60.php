<div class="<?php echo e($width); ?> px-4">

    <div class="relative w-full mb-3">

        <?php if($label): ?>
            <label
                class="block uppercase text-blueGray-600 text-xs font-bold mb-2
                    <?php echo e($attributes->has('required') ? 'required' : ''); ?>"
                for="<?php echo e($id ?? $name); ?>"
            >
                <?php echo e($label); ?>

            </label>
        <?php endif; ?>

        <select
            class="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
            name="<?php echo e($name); ?>"
            id="<?php echo e($id ?? $name); ?>"
            <?php echo e($attributes); ?>

        >

            <?php echo e($slot); ?>


            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Form\Option::class, ['value' => $option->value,'description' => $option->description,'selected' => $isSelected($option->value)]); ?>
<?php $component->withName('form.option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785)): ?>
<?php $component = $__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785; ?>
<?php unset($__componentOriginalaf92f2a1131e86a078636c53cf5d93f1b9c24785); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-red-600">
            <?php echo e($message); ?>

        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/components/form/select.blade.php ENDPATH**/ ?>