<div <?php echo e($attributes->merge(['class' => 'mb-12 xl:mb-0 px-4'])); ?> >
    <div class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">

        <?php echo e($slot); ?>


    </div>
</div>
<?php /**PATH C:\Users\Felipe\Documents\Trabalhos\Elipse\resources\views/components/layout/box.blade.php ENDPATH**/ ?>