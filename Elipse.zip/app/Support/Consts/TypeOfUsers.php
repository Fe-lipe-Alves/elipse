<?php

namespace App\Support\Consts;

class TypeOfUsers
{
    public const ADMIN = 1;
    public const STUDENT = 2;
    public const TEACHER = 3;
    public const SECRETARY = 4;
}
