<?php

namespace App\Support\Consts;

class GradeTypes
{
    public const ELEMENTARY = 1;
    public const HIGH = 2;
}
